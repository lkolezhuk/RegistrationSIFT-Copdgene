1. MAIN_HOMOGRAPHY.m - demonstrates the result of homography computation for all possible transformation types
2. ransacDEMO.m - demonstrates the performance of the RANSAC algorithm on the images of skin
3. reprojection_error_final_version.m - displayes all the backward and direct transformations for the synthetic data