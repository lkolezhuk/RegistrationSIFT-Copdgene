clear all;
close all;
clc;


f_path = 'C:/Users/Admin/Documents/Education/MAIA-Spain/Registration/PROJECTv2/';
voxel_spacing = GetVoxelSpacing(1); %load isotropix voxel spacing matrix(1,1,1)
pt = transformToTransformixPtsFile('C:/Users/Admin/Documents/Education/MAIA-Spain/Registration/PROJECT/dataset/' , 'C:/Users/Admin/Documents/Education/MAIA-Spain/Registration/PROJECTv2/', voxel_spacing);
voxel_spacing = GetVoxelSpacing(0); % change to real voxel spacing matrix (from the dataset parameters)

error_initial=cell(4);
error_reg=cell(4);
for i=7:7
    %% Masking
%      maskf = getLungMask([f_path 'input/pair' num2str(i) '/' 'fixed.img']);
%      imwrite(maskf, [f_path 'input/pair' num2str(i) '/' 'fixed_mask.img']);
%      ID = fopen([f_path 'input/pair' num2str(i) '/' 'fixed_mask.raw'],'w');
%      ImI = fwrite(ID, maskf.img);
%      fclose(ID);

%      save_nii(maskf,[f_path 'input/pair' num2str(i) '/' 'fixed_mask.img']);
%      maskm = getLungMask([f_path 'input/pair' num2str(i) '/' 'moving.img']);
%      imwrite(maskm, [f_path 'input/pair' num2str(i) '/' 'moving_mask.img']);
%      ID = fopen([f_path 'input/pair' num2str(i) '/' 'moving_mask.raw'],'w');
%      ImI = fwrite(ID, maskm.img);
%      fclose(ID);
%      save_nii(maskm,[f_path 'input/pair' num2str(i) '/' 'moving_mask.img']);
% ' -fMask ' f_path 'input/pair' num2str(i) '/' 'moving_mask.img' ' -mMask ' f_path 'input/pair' num2str(i) '/' 'fixed_mask.img' 
%%    
     elastixCMD = ['elastix -m ' f_path 'input/pair' num2str(i) '/' 'fixed.img'  ' -f ' f_path 'input/pair' num2str(i) '/' 'moving.img' ' -out ' f_path  'output/pair' num2str(i) '/ -p ' f_path 'input/parameters_Affine.txt' ' -p ' f_path 'input/parameters_BSpline.txt' ];
     transformixCMD = ['transformix -def ' f_path 'input/pair' num2str(i) '/' 'fixedpoints.txt' ' -out '  f_path  'output/pair' num2str(i) '/'  ' -tp ' f_path  'output/pair' num2str(i) '/' 'TransformParameters.1.txt'];

     system(elastixCMD); %run registration process
     system(transformixCMD); %run transformation of the points
     
     [reg_input_pts, reg_output_pts] = ReadOutputPoints(f_path, ['output\pair' num2str(i) '\outputpoints.txt'], true); 
%      [error_initial{i,1},error_initial{i,2}] = GetLandMarkErrorsMSE(pt{i,1}, pt{i,2}, voxel_spacing{i});
%      [error_reg{i,1}, error_reg{i,2}] = GetLandMarkErrorsMSE(pt{i,2}, reg_output_pts', voxel_spacing{i});
%      
%      disp(['Error before registration: ' num2str(error_initial{i})]);
%      disp(['Error after registration: ' num2str(error_reg{i})]);
%      
%      figure, scatter3(reg_output_pts(:,1), reg_output_pts(:,2), reg_output_pts(:,3), 'xb');
%      hold on; scatter3(pt{i,2}(1,:), pt{i,2}(2,:), pt{i,2}(3,:), 'xr'); 
%      hold on; scatter3(pt{i,1}(1,:), pt{i,1}(2,:), pt{i,1}(3,:), 'xm'); 
end