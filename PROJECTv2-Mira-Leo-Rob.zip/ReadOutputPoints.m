function [input, output] = ReadOutputPoints(f_path, file_path, as_index)
    fileID = fopen([f_path file_path]);
    out_pts_cell = textscan(fileID,'%s');
    fclose(fileID);

    out_pts_string = strjoin(out_pts_cell{1,1});
    [matching_strs,~] = regexpi(out_pts_string,'\[ *[+-]?([0-9]*[.])?[0-9]+ [+-]?([0-9]*[.])?[0-9]+ [+-]?([0-9]*[.])?[0-9]+ *\]','match', 'tokens');

    num_params = 5;
    output_points = zeros(300, num_params, 3);
    for j=0:299
        for jj = 1: num_params
            pts_temp = str2double(regexp(matching_strs{j*5 + jj},'\.*[+-]?(\d+(\.\d+)*)','match'));
            output_points(j+1, jj, :) = pts_temp(:);
        end
    end
   cd(f_path);
   
   if(as_index == true)
    input = [output_points(:,1,1) output_points(:,1,2) output_points(:,1,3)]; 
    output = [output_points(:,3,1) output_points(:,3,2) output_points(:,3,3)];
   else
    input = [output_points(:,2,1) output_points(:,2,2) output_points(:,2,3)]; 
    output = [output_points(:,4,1) output_points(:,4,2) output_points(:,4,3)]; 
   end
   
   
end

