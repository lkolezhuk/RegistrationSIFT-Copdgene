

%volume=load_untouch_nii('e_denoised_not_rotate.nii');
%volume=load_untouch_nii('e_not_denoised.nii');

%all_volume_slices=volume.img;

%upload the raw image;


function mask = getLungMask(filename)
    ID = fopen(filename);
    ImI = fread(ID, 'int16');
    fclose(ID);
    DimX = 512; DimY = 512;
    DimZ = numel(ImI) / (DimX * DimY );
    all_volume_slices = reshape(ImI, [DimX, DimY, DimZ]);




    %normalize the image between 0 and 1

    for slice_number=1:size(all_volume_slices,3)

    %delete the negative intensity
    pos=find(all_volume_slices<0);
    all_volume_slices(pos)=0;

    im_norm=mat2gray(all_volume_slices);



    one_slice=im_norm(:,:,slice_number);

    %compute the level of threshold in the original image
    level=graythresh(im_norm(:,:,slice_number));

    %apply it in the image translated between o and 1
    BW = imbinarize(im_norm(:,:,slice_number),level);
    %imshowpair(all_volume_slices(:,:,slice_number),BW,'montage');

    %build a structure for morphological opertion
    se = strel('disk',10);
    afterOpening = imopen(BW,se);
    %imshowpair(afterOpening,BW,'montage')
    neg_after_opening=1-afterOpening;

    IM_mask = imclearborder(neg_after_opening);
    mask(:, :, slice_number) = IM_mask;
    image_pre=all_volume_slices(:,:,slice_number).*IM_mask;

    %image_pre=one_slice.*neg_after_opening;
    IM2(:,:,slice_number) = imclearborder(image_pre);



    end
    mask = make_nii(IM2);
end


