function [error, standard_deviation] = GetLandMarkErrorsMSE(input_points, output_points, voxel_spacing)
    
sum_value=0;

        for i=1:length(input_points)
       
                 sum_value = sum_value + (voxel_spacing(i,1)*(input_points(1,i)-output_points(1,i)))^2;
                 sum_value = sum_value + (voxel_spacing(i,2)*(input_points(2,i)-output_points(2,i)))^2;
                 sum_value = sum_value + (voxel_spacing(i,3)*(input_points(3,i)-output_points(3,i)))^2;

                 d(i)=sqrt(sum_value);
            sum_value=0;
        end
        
        error_final=sum(d)/300;
        standard_deviation = std(d);
        error=error_final;             
         
end

