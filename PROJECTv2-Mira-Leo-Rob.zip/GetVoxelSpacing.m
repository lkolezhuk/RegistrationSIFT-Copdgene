function [voxel_spacing] = GetVoxelSpacing(is_raw)
    if(is_raw == 1)
        pixelsize=[1 1 1];
        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{1}=repmat(pixelsize,[300 1]);

        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{2}=repmat(pixelsize,[300 1]);

        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{3}=repmat(pixelsize,[300 1]);

        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{4}=repmat(pixelsize,[300 1]);
        
        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{5}=repmat(pixelsize,[300 1]);
        
        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{6}=repmat(pixelsize,[300 1]);
        
        
        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{7}=repmat(pixelsize,[300 1]);
    else  
        pixelsize=[0.625 0.625 2.5];
        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{1}=repmat(pixelsize,[300 1]);
        pixelsize=[0.645 0.645 2.5];
        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{2}=repmat(pixelsize,[300 1]);
        pixelsize=[0.652 0.652 2.5];
        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{3}=repmat(pixelsize,[300 1]);
        pixelsize=[0.59  0.59  2.5];
        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{4}=repmat(pixelsize,[300 1]);
        
        pixelsize=[0.647  0.647  2.5];
        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{5}=repmat(pixelsize,[300 1]);
        
        
        pixelsize=[0.633  0.633  2.5];
        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{6}=repmat(pixelsize,[300 1]);
        
        
        pixelsize=[0.633  0.633  2.5];
        vector_pixel_size=repmat(pixelsize,[300 1]);
        vector_pixel_size_cell{7}=repmat(pixelsize,[300 1]);
    end
    voxel_spacing = vector_pixel_size_cell;
end

