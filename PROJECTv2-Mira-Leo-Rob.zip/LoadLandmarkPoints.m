function [points, error] = LoadLandmarkPoints(path)


%upload the txt file in a structure point_txt{:,:}, where the row corrispond to different
%patience and the column to different image of the same patient. Moreover
%the point has to be multiply for pixel spacing
pixelsize=[1 1 1]
vector_pixel_size=repmat(pixelsize,[300 1]);
vector_pixel_size_cell{1}=repmat(pixelsize,[300 1]);

pixelsize=[1 1 1]
vector_pixel_size=repmat(pixelsize,[300 1]);
vector_pixel_size_cell{2}=repmat(pixelsize,[300 1]);

pixelsize=[1 1 1]
vector_pixel_size=repmat(pixelsize,[300 1]);
vector_pixel_size_cell{3}=repmat(pixelsize,[300 1]);

pixelsize=[1 1 1]
vector_pixel_size=repmat(pixelsize,[300 1]);
vector_pixel_size_cell{4}=repmat(pixelsize,[300 1]);







mat_files = dir(path);
folder_list_data=mat_files(~ismember({mat_files.name},{'.','..'}));
for i=1:size(folder_list_data,1)
filename = folder_list_data(i).name;
txt_folder_path = strcat(path, filename);
txt_folder=dir(fullfile(txt_folder_path, '*.txt'));
    for j=1:size(txt_folder,1)
        filename_txt = txt_folder(j).name;
        [points_txt{i,j},delimiterOut]=importdata(strcat(txt_folder_path,'/',filename_txt));
        points_txt{i,j}=points_txt{i,j}';  
        points_txt{i,j}=points_txt{i,j}(:,:).*vector_pixel_size_cell{i}';

                
    end
end



%computing the MSE



sum_value=0;
for k=1:size(points_txt,1)
   
        for i=1:size( points_txt{1,1},2)
            for j=1:size(points_txt{1,1},1)
                sum_value=sum_value+(points_txt{k,1}(j,i)-points_txt{k,2}(j,i))^2;
            end
            d(i)=sqrt(sum_value);
           
            sum_value=0;
        end
         error_final(k)=sum(d)/300;
         d=[];
end

points=points_txt;
error=error_final;
