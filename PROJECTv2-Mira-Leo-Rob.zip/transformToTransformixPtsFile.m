function [points] = transformToTransformixPtsFile(dataset_path, output_path, vector_pixel_size_cell)
    

    mat_files = dir(dataset_path);
    folder_list_data=mat_files(~ismember({mat_files.name},{'.','..'}));
    for i=1:size(folder_list_data,1)
        filename = folder_list_data(i).name;
        txt_folder_path = strcat(dataset_path, filename);
        txt_folder=dir(strcat(txt_folder_path, '/*.txt'));
        for j=1:size(txt_folder,1)
            filename_txt = txt_folder(j).name;
            [points{i,j},delimiterOut]=importdata(strcat(txt_folder(j).folder,'\',filename_txt));
            points{i,j}=points{i,j}';  
            points{i,j}=points{i,j}(:,:) .* vector_pixel_size_cell{i}';
        end
        
        fileID = fopen([output_path 'input/pair' num2str(i) '/fixedpoints.txt'],'w');
        fprintf(fileID, ['index\n' num2str(300) '\n']);
        fprintf(fileID, '%f\t%f\t%f\n', (points{i,1}));
        fclose(fileID);
        
%         fileID = fopen([output_path, 'input/pair', num2str(i), '/movingpoints.txt'],'w');
%         fprintf(fileID, ['index\n' num2str(300) '\n']);
%         fprintf(fileID, '%f\t%f\t%f\n', (points{i,2}));
%         fclose(fileID);  

    end
end

