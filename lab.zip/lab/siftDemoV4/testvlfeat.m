clear all;
close all;
clc;

I = imread('retina1.pgm');

I = single(I) ;
[f,d] = vl_sift(I) ;