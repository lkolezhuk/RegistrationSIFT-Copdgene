close all;
clear all;
clc;

[image,d,l] = sift('retina1.pgm');

imageWithMarkers = image;
imageWithMarkers = insertMarker(imageWithMarkers, [l(:, 2) l(:, 1)] ,'x','color','blue','size',5);


figure;
imshow(imageWithMarkers,[]);