function vl_assert_equal(x, y, varargin)
  assert(isequaln(x,y),varargin{:}) ;
end
